﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Board board = null;
        Color myColor = Color.White;
        private void Form1_Load(object sender, EventArgs e)
        {
            board = Board.InitBoard(Color.Blue, Color.Black);

            ICell[,] cells = null;
            DialogResult result = MessageBox.Show("Do you want white color?", "White Or Black", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
                myColor = Color.Blue;
            else
                myColor = Color.Black;

            cells = board.StartGame(myColor);

            for (int x = 0; x < 8; x++)
            {
                for (int y = 0; y < 8; y++)
                {
                    panelBoard.Controls.Add((Control)cells[x, y]);
                    cells[x, y].Click += new EventHandler(Form1_Click);
                }
            }
        }

        void Form1_Click(object sender, EventArgs e)
        {
            //if (board.ColorTurn != myColor)
            //    return;

            board.ClickCell((sender as Cell).Position.X, (sender as Cell).Position.Y);   
        }
    }


    public class Cell : Button, ICell
    {
        private IPiece piece = null;
        public IPiece Piece
        {
            get
            {
                return piece;
            }
            set
            {
                piece = value;
                if (value != null)
                {
                    this.Text = value.Name;
                    this.ForeColor = value.Color;
                    IsEmpty = false;
                }
                else
                    IsEmpty = true;
            }
        }

        public bool IsEmpty { get; set; }

        public Position Position { get; set; }

        public void RemovePiece()
        {
            this.Piece = null;
            this.Text = string.Empty;
        }
    }
}
